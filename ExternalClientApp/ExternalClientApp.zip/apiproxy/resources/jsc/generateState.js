var state = Math.random().toString(36).substring(7);
context.setVariable("generated.state", state);